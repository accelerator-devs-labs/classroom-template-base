// Punto de entrada de la semana
console.log('Hola desde el template de Classroom');
